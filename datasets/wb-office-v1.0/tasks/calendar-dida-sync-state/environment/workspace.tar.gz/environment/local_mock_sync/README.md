# Sync Environment

This environment is a file-backed sync workspace for the calendar-to-task synchronization task.

- There is no live external service, browser session, identity material, or network dependency.
- The calendar source, task/reminder state, stable sync history, policy, notes, and summary are represented by files under `input/workspace/`.
- Read the listed JSON/Markdown/text files and update only the mutable files named by the instruction and policy.
- Any behavior that would require external service access must be treated as out of scope.

Mutable public files for the task:

- `input/workspace/tasks/task_state.json`
- `input/workspace/sync/sync_history.json`
- `input/workspace/reports/sync_summary.md`

Read-only public files for the task:

- `input/workspace/README_先读我.md`
- `input/workspace/calendar/calendar_export_2026-07-14.json`
- `input/workspace/rules/sync_policy.md`
- `input/workspace/notes/operator_notes.txt`
- `environment/local_mock_sync/README.md`
- `environment/state_diff_manifest.json`
