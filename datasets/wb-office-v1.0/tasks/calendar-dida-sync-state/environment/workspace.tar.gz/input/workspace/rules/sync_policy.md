# 日历到待办/提醒同步规则

本规则只适用于本任务目录内的导出日历快照、工作区待办状态和说明文件。不要连接、登录、探测或调用任何真实日历、待办、提醒、通知、外部服务、网络 URL 或 live service。

## 1. 同步范围

- 本轮运行时间：`2026-07-14T18:20:00+08:00`
- 时区：`Asia/Shanghai`
- 当前同步窗口：`2026-07-15T00:00:00+08:00` 到 `2026-07-21T23:59:59+08:00`
- 可同步来源必须同时满足：
  - `calendar_id` 对应的日历在 calendar export 的 `calendars` 中 `sync_allowed=true`；
  - `start_time` 落在当前同步窗口内；
  - `status` 为 `confirmed` 或 `tentative` 时可创建/更新，`status=cancelled` 时只对已有稳定匹配项做 inactive 处理；
  - 不是重复导出行，也不是只读/归档/窗口外来源。

## 2. 稳定匹配优先级

1. 先查 `sync_history.json` 中 `state=active` 且 `sync_key` 相同的 mapping。
2. 再查 `task_state.json` 中 `source.sync_key` 相同且 `status=active` 的任务。
3. 只有在没有 active history、没有 active task 侧同步键匹配时，才允许为合格日历来源新建工作区待办/提醒。
4. 即使某个日历记录看起来像新事项，也要先排查历史或目标侧是否已有同一 `sync_key` 的手机端/缓存同步项，不能因为旁边有标题相近的手工任务就另建。
5. 标题相似、时间接近、人工备注写着“像是同一件事”等都不能单独作为匹配依据；同名但 `uid`/`sync_key` 不同的来源实例要分别按稳定键和历史状态处理。
6. `source.kind=manual`、`source.sync_key=null` 或 `manual_lock=true` 的任务，一律视为手工/无关任务，不得被同步覆盖。

## 3. 新建待办

对符合同步范围且没有稳定匹配的日历记录：

- 在 `task_state.json.tasks` 中追加一条工作区待办/提醒。
- 新任务应包含 `source.kind="mock_calendar"`、`source.sync_key`、`source.event_uid`、`source.event_id`、`source.calendar_id`、`source.last_source_updated_at`、`source.last_synced_at`。
- `due_time` 按 `event.start_time + task_hint.due_offset_minutes` 计算。
- `reminder_time` 可等于 `due_time` 或早于 `due_time` 十分钟，保持一致即可。
- `tags` 应包含 `calendar-sync` 和来源 `task_hint.tags` 中适用的标签。
- 同一个 `sync_key` 只能产生一个 active 待办和一个 active mapping。

## 4. 更新已有同步待办

对有 active 稳定匹配的 confirmed/tentative 来源：

- 只更新日历同步管理字段，例如 `title` 中的同步标题、`due_time`、`reminder_time`、`priority`、`tags` 中的同步标签、`source.event_id`、`source.last_source_updated_at`、`source.last_synced_at`、`sync_fields.source_*`、`updated_at`。
- `task_hint.target_list` 表示日历侧建议列表；若已经存在 active 稳定匹配，除非目标任务没有有效 `list_id`，不要仅凭该提示迁移既有任务所在列表。
- 保留 `task_id`、`created_at`、`manual_note`、`manual_tags`、`manual_lock` 和其他手工字段。
- 若当前 JSON 已经与来源一致，则保持不变，不要为了“证明处理过”而改时间戳。

## 5. 取消和来源缺失的 inactive 语义

- 如果当前导出里有 `status=cancelled` 的日历记录，且存在 active 稳定匹配任务：
  - 将目标任务设为 `status="inactive"`；
  - 将 `archived` 设为 `true`；
  - 将 `sync_fields.inactive_reason` 设为 `calendar_event_cancelled`；
  - 更新 `source.event_id`、`source.last_source_updated_at`、`source.last_synced_at`、`updated_at`；
  - 不要删除任务，不要清空手工备注或手工标签。
- 如果 `sync_history.json` 中 active mapping 标记 `missing_in_current_export=true`，且目标任务 `due_time` 仍落在当前同步窗口内：
  - 将目标任务设为 `status="inactive"`；
  - 将 `archived` 设为 `true`；
  - 将 `sync_fields.inactive_reason` 设为 `source_missing_current_export`；
  - 将该 mapping 的 `state` 更新为 `inactive`，`last_action` 记录为来源缺失相关动作；
  - 不要删除任务。
- 如果来源缺失但目标任务不在当前同步窗口内，或 mapping 已经 inactive/excluded，则本轮不要改动。

## 6. 重复、只读和排除项

- 多条 calendar event 共享同一个 `sync_key` 时，只处理一条主记录；其他行写入或保留在 `sync_history.json.suppressed_duplicates`，不能生成第二个 active 任务。
- 重复行可能出现在同日备份、移动端缓存或同步窗口边界附近；只要 `sync_key` 与已选主记录或 active mapping 相同，就按重复抑制处理，不能用不同 `event_id` 或标题后缀生成第二个待办。
- `sync_allowed=false` 的日历、`source_flags` 包含 `do_not_sync` 的记录、窗口外记录、归档日历记录，不创建任务，不更新手工任务。
- 已有 excluded/inactive 历史记录可以保留，但不得升级成 active mapping，除非它对应一个新的合格来源且没有 active 冲突。

## 7. 输出文件和摘要结构

只允许更新：

- `input/workspace/tasks/task_state.json`
- `input/workspace/sync/sync_history.json`
- `input/workspace/reports/sync_summary.md`

`sync_summary.md` 必须保留以下稳定标题，便于人工和程序检查：

1. `## 本轮同步结论`
2. `## 新建待办`
3. `## 更新已有同步项`
4. `## 置为 inactive`
5. `## 保持不变`
6. `## 重复或排除`
7. `## 手工/无关任务保留`
8. `## 边界确认`

每个项目尽量引用 `event_id`、`sync_key` 或 `task_id`。摘要中的分类、原因和 item references 必须与两个 JSON 文件的实际状态一致。
