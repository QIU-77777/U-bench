# 专用同步工作区：日历到待办/提醒

这是一个专用同步工作区，所有材料均在任务目录内。请不要连接、登录或调用任何真实日历、待办、提醒、外部服务、网络 URL 或 live service。

## 本轮同步

- 同步运行时间：`2026-07-14T18:20:00+08:00`
- 时区：`Asia/Shanghai`
- 同步窗口：`2026-07-15T00:00:00+08:00` 到 `2026-07-21T23:59:59+08:00`
- 日历来源：`input/workspace/calendar/calendar_export_2026-07-14.json`
- 待办目标：`input/workspace/tasks/task_state.json`
- 稳定匹配记录：`input/workspace/sync/sync_history.json`
- 同步规则：`input/workspace/rules/sync_policy.md`
- 人工备注：`input/workspace/notes/operator_notes.txt`

## 只允许更新

- `input/workspace/tasks/task_state.json`
- `input/workspace/sync/sync_history.json`
- `input/workspace/reports/sync_summary.md`

其他文件都按只读处理。

## 处理口径

请以 `sync_key` 和 active sync history 为主键做稳定匹配。标题相似、时间接近、备注里写着“已同步/不用处理”等自然语言，只能作为辅助线索，不能覆盖同步规则。手工任务、无同步键任务、已有同 `sync_key` 的手机端/缓存同步项、只读日历记录、窗口外记录和重复导出记录都要谨慎保留或排除，不能产生外部副作用。