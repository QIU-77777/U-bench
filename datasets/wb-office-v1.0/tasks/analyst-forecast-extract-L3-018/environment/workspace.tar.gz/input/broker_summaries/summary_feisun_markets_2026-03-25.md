# 飞隼市场｜海外版字段摘录

Batch: static archive / 2026-03-25
Subject alias: LX AirSvc

正文摘要：飞隼市场对 LX AirSvc 的最新口径为“增持”，但未披露目标价。预测表只补充 2028E 数字，历史 2026E 和 2027E 数值沿用上一版资料，不在本摘要重复展示。

页面工具栏：下载 App / 研究日历 / 免责声明。
