from __future__ import annotations


def stream_scan_events(job_path: str):
    # Draft helper for design discussion; not wired into CLI or public API docs.
    raise NotImplementedError("experimental only")


def sync_remote_profile(profile_name: str) -> None:
    # Roadmap placeholder; no supported service endpoint exists in this sample.
    raise NotImplementedError("remote profile sync is not supported")
