from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .config import load_profile


@dataclass
class ScanResult:
    job_id: str
    records: list[dict[str, Any]]
    warning_count: int

    def to_records(self) -> list[dict[str, Any]]:
        return list(self.records)

    def to_summary(self) -> str:
        return f"job={self.job_id}; warnings={self.warning_count}; records={len(self.records)}"


class ScanClient:
    def __init__(self, settings: dict[str, Any]):
        self.settings = settings

    @classmethod
    def from_profile(cls, profile_name: str) -> "ScanClient":
        settings = load_profile(profile_name)
        return cls(settings=settings)

    def scan_job(self, job_path: str, include_warnings: bool = False) -> ScanResult:
        job_id = job_path.rsplit("/", 1)[-1].replace(".yaml", "")
        records: list[dict[str, Any]] = [
            {
                "record_type": "summary",
                "job_id": job_id,
                "status": "ok",
                "message": "2 checks completed",
            },
            {
                "record_type": "metric",
                "job_id": job_id,
                "status": "ok",
                "metrics": {"duration_seconds": 3.7, "checked_items": 2},
            },
        ]
        if include_warnings:
            records.append(
                {
                    "record_type": "warning",
                    "job_id": job_id,
                    "status": "warning",
                    "message": "optional field owner was not set",
                }
            )
        return ScanResult(job_id=job_id, records=records, warning_count=int(include_warnings))
