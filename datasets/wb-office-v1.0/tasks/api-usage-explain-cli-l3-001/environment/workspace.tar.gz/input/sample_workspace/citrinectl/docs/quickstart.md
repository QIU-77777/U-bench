# Quickstart

The fastest supported workflow is to run `citrinectl scan JOB_FILE` from the
repository root or from another directory that can reference a Citrine job YAML
file.

```bash
citrinectl scan tests/fixtures/minimal_job.yaml
```

Common flags:

- `--profile NAME` selects a named profile after packaged defaults are loaded.
  The examples use `local-dev` for short timeouts and JSONL output.
- `--format table|jsonl|summary` chooses the rendering mode for the CLI output.
  If the flag is omitted, the resolved profile/default configuration decides the
  mode.
- `--include-warnings` keeps warning records in JSONL and summary output. Without
  it, warning details may be summarized instead of emitted as separate records.

A second command, `citrinectl explain JOB_FILE`, prints configuration and schema
notes for the same job file. It accepts `--profile NAME`, but it does not accept
`--format` because it is meant for human-readable inspection notes.

This page is a practical CLI introduction. It does not describe the Python API,
all config precedence rules, or the full JSONL record schema.
