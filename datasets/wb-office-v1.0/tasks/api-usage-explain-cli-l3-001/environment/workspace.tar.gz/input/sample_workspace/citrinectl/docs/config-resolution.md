# Config Resolution

Configuration is resolved in layers. Later layers override earlier layers only
for fields they actually provide.

1. Packaged defaults from `config/defaults.yaml`.
2. Named profile values from `config/profiles.example.yaml` or from a user-provided
   profile file.
3. CLI flags for fields that are exposed by the active command parser.

The default profile name is `default`. A named profile can change `scan.timeout`,
`scan.retry_count`, `output.format`, and `output.include_warnings` without adding
new CLI commands.

Environment variables are intentionally limited:

- `CITRINE_PROFILE_FILE` points to an alternate profile YAML file.
- `CITRINE_DEFAULT_PROFILE` changes the profile name used when `--profile` is not
  supplied.

Environment variables are not replacements for every CLI option. In particular,
there is no supported environment variable for forcing a one-off output format;
use `--format` for the CLI or call a `ScanResult` adapter in Python.
