# Glossary

This page defines project terminology. It is useful context but not a complete
usage reference.

- Job file: a YAML document that names a scan target and optional checks.
- Profile: a named group of retry, timeout, and output settings.
- Record: a JSON-compatible object emitted by the scanner or returned by the API.
- Warning: a non-fatal issue that may be included or summarized depending on the
  selected output mode.

Some glossary terms are shared with older examples. Confirm current command and
API behavior against parser source, current docs, and schemas before describing
supported usage.
