# Migration Notes from v1

These notes describe historical behavior from an earlier internal draft of the
sample project. They are kept for context because some older snippets still use
outdated names.

Older drafts used `--json` as a shortcut for machine-readable output. The current
CLI parser uses `--format jsonl` instead. Older drafts also mentioned a
`citrinectl run` command; the supported command in the current parser is
`citrinectl scan`.

Do not rely on archived snippets or screenshots when checking current behavior.
Prefer the current parser source, maintained docs, examples, and schemas.
