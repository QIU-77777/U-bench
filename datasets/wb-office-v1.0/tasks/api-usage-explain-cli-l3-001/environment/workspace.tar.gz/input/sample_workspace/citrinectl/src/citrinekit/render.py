from __future__ import annotations

import json

from .client import ScanResult


def render_result(result: ScanResult, output_format: str, include_warnings: bool = False) -> str:
    if output_format == "jsonl":
        records = result.to_records()
        if not include_warnings:
            records = [record for record in records if record.get("record_type") != "warning"]
        return "\n".join(json.dumps(record, sort_keys=True) for record in records)
    if output_format == "summary":
        summary = result.to_summary()
        if include_warnings and result.warning_count:
            return summary + "; warning_details=included"
        return summary
    if output_format == "table":
        return "JOB ID        STATUS    RECORDS\n" + f"{result.job_id:<13} ok        {len(result.records)}"
    raise ValueError(f"unsupported output_format: {output_format}")
