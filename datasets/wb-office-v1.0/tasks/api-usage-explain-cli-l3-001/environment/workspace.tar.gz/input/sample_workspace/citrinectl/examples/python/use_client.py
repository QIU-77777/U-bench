from citrinekit.client import ScanClient

client = ScanClient.from_profile("local-dev")
result = client.scan_job("tests/fixtures/minimal_job.yaml", include_warnings=True)
for record in result.to_records():
    print(record)

print(result.to_summary())
