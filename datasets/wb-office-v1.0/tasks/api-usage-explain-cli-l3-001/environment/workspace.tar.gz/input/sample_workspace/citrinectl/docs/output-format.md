# Output Format

The CLI supports three rendering modes:

- `table`: a short terminal table intended for manual inspection.
- `summary`: a compact textual summary with counts and the final status.
- `jsonl`: newline-delimited JSON records suitable for downstream tools.

When JSONL is selected, each line is a single object. The current record families
are `summary`, `metric`, and `warning`. The machine-readable contract is described
in `schemas/scan-result.schema.json`; example output is available in
`examples/output/scan_summary.jsonl`.

Warning handling differs by mode. In `jsonl`, warning records are emitted only
when `include_warnings` resolves to true. In `summary`, warnings are folded into
the final line unless the caller explicitly asks to include warning details. The
`table` mode is intentionally terse and may show a warning count without the full
warning message.

The renderer does not currently emit XML, CSV, or remote webhook events. Draft
notes about future streaming should be treated as planning material unless the
CLI parser or API documentation wires them into supported behavior.
