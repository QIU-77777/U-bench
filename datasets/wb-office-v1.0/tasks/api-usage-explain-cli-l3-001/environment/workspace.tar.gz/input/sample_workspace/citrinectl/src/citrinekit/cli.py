from __future__ import annotations

import argparse
from pathlib import Path

from .client import ScanClient
from .config import load_profile
from .render import render_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="citrinectl")
    subcommands = parser.add_subparsers(dest="command", required=True)

    scan = subcommands.add_parser("scan", help="inspect a job file and emit scan output")
    scan.add_argument("job_file", help="path to a Citrine job YAML file")
    scan.add_argument("--profile", default=None, help="profile name after defaults are loaded")
    scan.add_argument(
        "--format",
        choices=["table", "jsonl", "summary"],
        default=None,
        help="CLI rendering mode; falls back to resolved config when omitted",
    )
    scan.add_argument(
        "--include-warnings",
        action="store_true",
        help="emit warning details when the selected format supports them",
    )
    scan.set_defaults(handler="run_scan")

    explain = subcommands.add_parser("explain", help="print config and schema notes for a job file")
    explain.add_argument("job_file", help="path to a Citrine job YAML file")
    explain.add_argument("--profile", default=None, help="profile name after defaults are loaded")
    explain.set_defaults(handler="run_explain")
    return parser


def run_scan(args: argparse.Namespace) -> str:
    settings = load_profile(args.profile)
    output_format = args.format or settings["output"]["format"]
    include_warnings = args.include_warnings or bool(settings["output"].get("include_warnings"))
    client = ScanClient(settings=settings)
    result = client.scan_job(str(Path(args.job_file)), include_warnings=include_warnings)
    return render_result(result, output_format=output_format, include_warnings=include_warnings)


def run_explain(args: argparse.Namespace) -> str:
    settings = load_profile(args.profile)
    return (
        f"job={args.job_file}; profile={settings['profile_name']}; "
        "schema=schemas/scan-result.schema.json"
    )


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    output = globals()[args.handler](args)
    print(output)
    return 0
