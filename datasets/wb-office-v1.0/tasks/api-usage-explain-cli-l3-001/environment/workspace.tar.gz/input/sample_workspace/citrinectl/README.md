# CitrineCtl Sample Workspace

`citrinectl` is a small sample command-line utility used in examples for
inspecting YAML job files and emitting operator-friendly scan output. The
project exposes both a CLI entry point and a lightweight Python API in the
`citrinekit` package.

Start with the docs under `docs/` when you need user-facing behavior. The
README is intentionally brief and should not be treated as the complete command,
API, configuration, or output-format reference.

Useful starting points:

- CLI onboarding: `docs/quickstart.md`
- Embedded Python usage: `docs/api-client.md`
- Configuration precedence: `docs/config-resolution.md`
- Output modes and records: `docs/output-format.md`

The examples and schemas in this sample repository are meant to be read together
with the source files under `src/citrinekit/`.
