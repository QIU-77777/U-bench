#!/usr/bin/env bash
set -euo pipefail

citrinectl scan tests/fixtures/minimal_job.yaml --profile local-dev --include-warnings
