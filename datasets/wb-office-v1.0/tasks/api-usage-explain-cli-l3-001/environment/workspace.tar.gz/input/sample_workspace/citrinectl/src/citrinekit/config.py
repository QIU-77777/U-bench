from __future__ import annotations

import os
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

DEFAULTS_PATH = Path(__file__).resolve().parents[2] / "config" / "defaults.yaml"
PROFILES_PATH = Path(__file__).resolve().parents[2] / "config" / "profiles.example.yaml"


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _read_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def load_profile(profile_name: str | None = None) -> dict[str, Any]:
    defaults = _read_yaml(DEFAULTS_PATH)
    profile_file = Path(os.environ.get("CITRINE_PROFILE_FILE", PROFILES_PATH))
    profile_doc = _read_yaml(profile_file)
    selected = profile_name or os.environ.get("CITRINE_DEFAULT_PROFILE") or defaults.get("default_profile", "default")
    profile_values = profile_doc.get("profiles", {}).get(selected, {})
    settings = _deep_merge(defaults, profile_values)
    settings["profile_name"] = selected
    return settings
