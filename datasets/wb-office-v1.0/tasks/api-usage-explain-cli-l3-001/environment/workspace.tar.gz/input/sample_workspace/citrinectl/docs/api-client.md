# Python API Client

Use the Python API when embedding the scanner in another tool instead of shelling
out to `citrinectl`.

```python
from citrinekit.client import ScanClient

client = ScanClient.from_profile("local-dev")
result = client.scan_job("tests/fixtures/minimal_job.yaml", include_warnings=True)
for record in result.to_records():
    print(record)
```

Public entry points:

- `ScanClient.from_profile(profile_name)` builds a client from resolved config.
- `ScanClient.scan_job(job_path, include_warnings=False)` returns a `ScanResult`.
- `ScanResult.to_records()` returns JSONL-compatible dictionaries.
- `ScanResult.to_summary()` returns a compact Markdown-friendly summary string.

The API does not expose every CLI rendering flag as a keyword argument. Rendering
is normally chosen after a `ScanResult` is returned. For example, callers can use
`to_records()` for JSONL-compatible dictionaries or `to_summary()` for a compact
summary, but there is no `format="table"` argument on `scan_job()`.
